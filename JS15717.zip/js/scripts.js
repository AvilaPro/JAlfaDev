// Declaracion de variables
// Precios de los productos
const PA = 100;
const PB = 200;
const PC = 500;

//variables de uso
let tipoProducto = "";
let cantidad = 0;
let precioUnitario = 0;
let precioTotal = 0;
let tipoCorrecto = false;

//Logica del negocio
//1.Comunicas que vende el negocio
alert("Bienvenido a nuestra tienda, tenemos los siguientes productos: \nProducto A: $100 \nProducto B: $200 \nProducto C: $500");

//2. Le solicitas al usuario el tipo de producto que desea comprar (A, B o C)
tipoProducto = prompt("¿Qué producto desea comprar? (A, B o C)");
// Manejar la respuesta
tipoProducto = tipoProducto.toUpperCase();

// 3. Determinas el precio unitario del producto seleccionado por el usuario
// Con estructura if

if (tipoProducto == "A") {
    precioUnitario = PA;
    tipoCorrecto = true;
} else if (tipoProducto == "B") {
    precioUnitario = PB;
    tipoCorrecto = true;
} else if (tipoProducto == "C") {
    precioUnitario = PC;
    tipoCorrecto = true;
} else {
    alert("Producto no válido");
}

// alert("El precio unitario del producto " + tipoProducto + " es: $" + precioUnitario);

if (tipoCorrecto) {
    //tipoCorrecto true quiere decir que el tipo es A, B o C
    
    /**Procedo a obtener la cantidad */
    // 4. Le solicitas al usuario la cantidad que desea comprar
    cantidad = parseInt(prompt("¿Cuántas unidades desea comprar?"));

    //5. Respuestas invalidas son Cadena Vacia, Texto o Null
    if(isNaN(cantidad)){
        //NO ES UN NUMERO
        alert("Cantidad no válida");
    } else {
        cantidad = parseFloat(cantidad);
        //- 6. Validar que sea positivo
        if(cantidad <= 0){
            alert("La cantidad debe ser positiva");
        } else {
            //CANTIDAD ES POSITIVA
            // 7. Calculas el precio total de la compra (precio unitario * cantidad)
            precioTotal = precioUnitario * cantidad;
            //8. Determinar el descuento
            // Si es mayor o igual a 12 aplico un 20%
            if (cantidad >= 12) {
                precioTotal = precioTotal * 0.8;
            }
            //9. Informo el total al usuario
            alert("El precio total de su compra es: $" + precioTotal);
        }
    }
}